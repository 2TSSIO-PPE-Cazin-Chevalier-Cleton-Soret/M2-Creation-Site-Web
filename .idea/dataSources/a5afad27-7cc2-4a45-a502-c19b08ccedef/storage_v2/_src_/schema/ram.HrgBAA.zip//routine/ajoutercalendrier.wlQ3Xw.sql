create procedure ajouterCalendrier(IN sante     varchar(255), IN temperature int, IN pleurs varchar(255),
                                   IN besoins   varchar(255), IN repas varchar(255), IN alimentation varchar(255),
                                   IN dodo      varchar(255), IN humeur varchar(255), IN activite varchar(255),
                                   IN promenade varchar(255), IN remarques varchar(255), IN date int, IN idEnfant int)
  INSERT INTO calendrier(sante, temperature, pleurs, besoins, repas, aliments, dodo, humeur, activite, promenade, remarques, date, idEnfant) VALUES (sante, temperature, pleurs, besoins, repas, aliments, dodo, humeur, activite, promenade, remarques, date, idEnfant);

