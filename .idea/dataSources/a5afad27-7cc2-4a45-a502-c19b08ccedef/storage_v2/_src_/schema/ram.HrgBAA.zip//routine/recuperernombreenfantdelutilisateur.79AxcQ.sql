create procedure recupererNombreEnfantDeLUtilisateur(IN idSession int)
  SELECT COUNT(*) 
FROM enfants 
WHERE idParent = idSession;

