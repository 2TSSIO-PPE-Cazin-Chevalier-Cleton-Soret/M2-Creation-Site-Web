create procedure ajouterEnfant(IN nom      varchar(255), IN prenom varchar(255), IN age int, IN idParent int,
                               IN idNounou int)
  INSERT INTO enfants(nom, prenom, age, idParent, idNounou) 
VALUES (nom, prenom, age, idParent, idNounou);

