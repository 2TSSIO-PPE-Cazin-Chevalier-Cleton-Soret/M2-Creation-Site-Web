create procedure recupererUtilisateur(IN pseudoVoulu varchar(255))
  SELECT id, pseudo, mdp, choix_nounou
FROM membres
WHERE pseudo = pseudoVoulu;

