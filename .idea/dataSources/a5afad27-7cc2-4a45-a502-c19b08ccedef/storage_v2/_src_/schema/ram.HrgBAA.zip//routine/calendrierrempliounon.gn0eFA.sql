create procedure calendrierRempliOuNon(IN enfant int)
  SELECT COUNT(*) 
FROM calendrier
WHERE idEnfant = enfant
AND date = CURDATE();

