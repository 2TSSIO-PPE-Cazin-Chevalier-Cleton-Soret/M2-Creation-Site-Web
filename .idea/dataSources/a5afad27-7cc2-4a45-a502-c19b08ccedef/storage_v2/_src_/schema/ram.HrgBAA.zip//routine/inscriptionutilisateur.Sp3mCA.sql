create procedure inscriptionUtilisateur(IN pseudo       varchar(255), IN mdp varchar(255), IN nom varchar(255),
                                        IN prenom       varchar(255), IN cp int, IN ville varchar(255),
                                        IN pays         varchar(255), IN email varchar(255), IN nbrEnfant int,
                                        IN type         varchar(255), IN choix_nounou int)
  INSERT INTO membres(pseudo, mdp, nom, prenom, cp, ville, pays, email, nbrEnfant, type, choix_nounou) VALUES(pseudo, mdp, nom, prenom, cp, ville, pays, email, nbrEnfant, type, choix_nounou);

