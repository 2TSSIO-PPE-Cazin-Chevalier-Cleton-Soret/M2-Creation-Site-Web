create procedure recupererEnfant(IN idSession int)
  SELECT *
FROM calendrier AS c
INNER JOIN enfants AS e on c.idEnfant = e.idEnfant
WHERE idParent = idSession AND date = CURDATE();

